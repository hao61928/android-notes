package com.example.hero1_000.jiemian;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

/**
 * Created by hero1_000 on 2016/12/18.
 */

public class myadapter extends BaseAdapter {
    private List<Map<String, Object>> data;
    private LayoutInflater layoutInflater;
    private Context context;

    public myadapter(Context context, List<Map<String, Object>> data) {
        //传入的data，就是我们要在listview中显示的信息
        this.context = context;
        this.data = data;
        this.layoutInflater = LayoutInflater.from(context);
    }
    //这里定义了一个类，用来表示一个item里面包含的东西，像我的就是一个imageView和三个TextView，按自己需要来
    public class Info {
        public ImageView tupian;
        public TextView shuxing;
        public TextView zhi;


    }
    //所有要返回的数量，Id，信息等，都在data里面，从data里面取就好
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }
    //跟actvity中的oncreat()差不多，目的就是给item布局中的各个控件对应好，并添加数据
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Info info = new Info();
        convertView = layoutInflater.inflate(R.layout.setitem, null);
        info.tupian = (ImageView) convertView.findViewById(R.id.bjtupian);
        info.shuxing = (TextView) convertView
                .findViewById(R.id.bjshuxing);
        info.zhi = (TextView) convertView
                .findViewById(R.id.bjzhi);


        //设置数据
       // info.tupian.setImageResource((Integer) data.get(position).get("amtupian"));
        info.shuxing.setText((String) data.get(position).get(
                "amshuxing"));
        info.zhi.setText((String) data.get(position).get(
                "amzhi"));
        if(position%2==0)
        {
            //convertView.setBackgroundColor(Color.parseColor("#ff00ff"));
           // convertView.setBackgroundResource(R.mipmap.ic_launcher);
        }
        return convertView;
    }

}
